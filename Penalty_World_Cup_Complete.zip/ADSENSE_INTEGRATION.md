<!-- ============================================
     📺 كود Google AdSense for Games
     ============================================ -->

<!-- 1. أضف هذا في <head> -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX"
     crossorigin="anonymous"></script>

<!-- 2. استبدل دالة watchAd() الحالية بهذه: -->
<script>
// ==========================================
// 📺 إعلانات Google AdSense (Rewarded Ads)
// ==========================================

// معرف الناشر (استبدله بمعرفك)
const ADSENSE_CLIENT_ID = 'ca-pub-XXXXXXXXXXXXXXXX';

/**
 * عرض إعلان مكافأة حقيقي
 */
function showRewardedAd() {
    // التحقق من وجود AdSense
    if (typeof adsbygoogle === 'undefined') {
        console.log('AdSense not loaded, using fallback');
        watchAdFallback();
        return;
    }

    // طلب إعلان مكافأة
    adsbygoogle.push({
        google_ad_client: ADSENSE_CLIENT_ID,
        google_ad_format: 'rewarded',
        google_full_width_responsive: true,
        google_ad_slot: 'REWARDED_AD_SLOT',
        // عند اكتمال الإعلان بنجاح
        google_rewarded_ad_callback: function() {
            console.log('Ad completed successfully');
            giveExtraAttempt();
        },
        // عند فشل تحميل الإعلان
        google_rewarded_ad_error_callback: function() {
            console.log('Ad failed to load');
            watchAdFallback();
        }
    });
}

/**
 * إعطاء ركلة إضافية بعد الإعلان
 */
function giveExtraAttempt() {
    extraAttempt = true;
    document.getElementById('adBtn').style.display = 'none';
    totalAttempts++;
    const dot = document.createElement('div');
    dot.className = 'attempt-dot';
    dot.id = `dot-${totalAttempts - 1}`;
    document.getElementById('attemptsBar').appendChild(dot);
    document.getElementById('scoreDisplay').textContent = `${goals} / ${totalAttempts}`;
    resetBall();

    // رسالة شكر
    alert('🎉 شكراً! حصلت على ركلة إضافية!');
}

/**
 * محاكاة الإعلان (احتياطي إذا فشل AdSense)
 */
function watchAdFallback() {
    document.getElementById('adScreen').classList.add('active');
    let timer = 5;
    const timerEl = document.getElementById('adTimer');
    const skipBtn = document.getElementById('skipBtn');
    timerEl.textContent = timer;
    skipBtn.disabled = true;
    skipBtn.textContent = '⏳ انتظر...';

    const countdown = setInterval(() => {
        timer--;
        timerEl.textContent = timer;
        if (timer <= 0) {
            clearInterval(countdown);
            skipBtn.disabled = false;
            skipBtn.textContent = '✅ استمرار';
        }
    }, 1000);
}

// استبدل onclick="watchAd()" بـ onclick="showRewardedAd()"
</script>

<!-- ============================================
     📺 إعلان ما قبل اللعب (Preroll Ad)
     ============================================ -->

<!-- أضف هذا قبل بدء اللعبة -->
<script>
/**
 * عرض إعلان قبل بدء اللعبة
 */
function showPrerollAd() {
    if (typeof adsbygoogle !== 'undefined') {
        adsbygoogle.push({
            google_ad_client: ADSENSE_CLIENT_ID,
            google_ad_format: 'preroll',
            google_full_width_responsive: true,
            google_ad_slot: 'PREROLL_AD_SLOT',
            google_preroll_ad_callback: function() {
                console.log('Preroll ad completed');
                startMatchAfterAd();
            }
        });
    } else {
        startMatchAfterAd();
    }
}

function startMatchAfterAd() {
    // استدعاء دالة startMatch() الأصلية
    startMatch();
}
</script>

<!-- ============================================
     📺 إعلان بيني (Interstitial Ad)
     ============================================ -->

<script>
/**
 * عرض إعلان بيني بعد كل 3 مباريات
 */
let gamesPlayed = 0;

function showInterstitialAd() {
    gamesPlayed++;
    if (gamesPlayed % 3 !== 0) {
        restartGame();
        return;
    }

    if (typeof adsbygoogle !== 'undefined') {
        adsbygoogle.push({
            google_ad_client: ADSENSE_CLIENT_ID,
            google_ad_format: 'interstitial',
            google_full_width_responsive: true,
            google_ad_slot: 'INTERSTITIAL_AD_SLOT',
            google_interstitial_ad_callback: function() {
                restartGame();
            }
        });
    } else {
        restartGame();
    }
}
</script>
