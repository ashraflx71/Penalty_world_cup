# ⚽ ركلة جزاء العالم | Penalty World Cup

<div align="center">

![Game Banner](https://img.shields.io/badge/⚽-Penalty%20World%20Cup-00ff88?style=for-the-badge)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)

**لعبة ركلات جزاء ثلاثية الأبعاد تفاعلية - اختر فريقك وسدد!**

[🎮 العب الآن](#-كيف-تلعب) • [📱 للجوال](#-للجوال) • [💰 الربح](#-نموذج-الربح)

</div>

---

## 🎯 نظرة عامة

**ركلة جزاء العالم** هي لعبة متصفح تفاعلية تعتمد على المهارة والتوقيت. اختر فريقك المفضل من 8 فرق عالمية وحاول تسجيل أكبر عدد من الأهدام في 5 ركلات جزاء!

### ✨ المميزات

- 🏟️ **ملعب ثلاثي الأبعاد** بتصميم احترافي
- 🧤 **حارس مرمى ذكي** يتحرك بناءً على صعوبة الفريق
- 🎨 **تأثيرات بصرية** متدرجة متحركة وجسيمات طافية
- 📱 **متجاوبة بالكامل** تعمل على الجوال والكمبيوتر
- 💰 **نظام ربح مدمج** (إعلانات مكافأة + نقاط + مشاركة)
- 🎮 **تحكم بسيط** بالأسهم وزر المسافة

---

## 🚀 كيف تلعب

### الخطوة 1: اختر فريقك
![Team Selection](https://via.placeholder.com/400x200/0a0a0f/00ff88?text=اختر+فريقك)

انقر على أحد 8 فرق عالمية:
- 🇧🇷 البرازيل
- 🇦🇷 الأرجنتين
- 🇫🇷 فرنسا
- 🇩🇪 ألمانيا
- 🇪🇸 إسبانيا
- 🇵🇹 البرتغال
- 🇮🇹 إيطاليا
- 🏴󠁧󠁢󠁥󠁮󠁧󠁿 إنجلترا

### الخطوة 2: سدد!
![Gameplay](https://via.placeholder.com/400x200/0a0a0f/ffd700?text=سدد+الكرة)

| التحكم | الوظيفة |
|--------|---------|
| `←` `→` | تحريك اتجاه التصويب |
| `مسافة` أو `سدد!` | التصويب |
| **الجوال** | اضغط على زر "سدد!" |

### الخطوة 3: اجمع النقاط!
- ⚽ كل هدف = نقاط بناءً على قوة التصويب
- 🎯 5 ركلات لكل مباراة
- 📺 شاهد إعلاناً للحصول على ركلة إضافية

---

## 💰 نموذج الربح

```
┌─────────────────────────────────────────┐
│  💵 نماذج الربح المتاحة                 │
├─────────────────────────────────────────┤
│  📺 إعلانات المكافأة (Rewarded Ads)     │
│     ↳ ركلة إضافية مقابل مشاهدة إعلان   │
├─────────────────────────────────────────┤
│  ⭐ نظام النقاط والتصنيف                │
│     ↳ تشجيع اللاعبين على العودة        │
├─────────────────────────────────────────┤
│  📤 مشاركة النتيجة                      │
│     ↳ تسويق فيروسي عبر وسائل التواصل   │
└─────────────────────────────────────────┘
```

### كيف تربح من اللعبة؟

1. **Google AdSense for Games** - أضف إعلانات حقيقية
2. **Firebase** - حفظ النقاط والتصنيف العالمي
3. **سكنات مدفوعة** - كرات ذهبية، ملاعب مشهورة
4. **اشتراك شهري** - إزالة الإعلانات + مكافآت يومية

---

## 📁 هيكل المشروع

```
penalty-world-cup/
│
├── 📄 index.html          ← الملف الرئيسي (HTML + CSS + JS)
├── 📄 README.md           ← هذا الملف
├── 📄 LICENSE             ← رخصة MIT
│
└── 📁 assets/             ← (اختياري) صور وأصوات
    ├── 🖼️ banner.png
    ├── 🔊 kick.mp3
    └── 🎵 crowd.mp3
```

---

## 🛠️ التثبيت والتشغيل

### الطريقة 1: فتح مباشر
```bash
# فقط افتح ملف index.html في أي متصفح
双击 index.html
```

### الطريقة 2: خادم محلي
```bash
# باستخدام Python
python -m http.server 8000

# باستخدام Node.js
npx serve .

# ثم افتح: http://localhost:8000
```

### الطريقة 3: GitHub Pages (موصى به)
```bash
# 1. أنشئ repository على GitHub
# 2. ارفع الملفات
# 3. فعّل GitHub Pages من Settings
# 4. احصل على رابط: yourname.github.io/penalty-world-cup
```

---

## 📱 للجوال

اللعبة متجاوبة بالكامل وتعمل على:
- 📱 iPhone / Android
- 📱 iPad / Tablets
- 💻 الكمبيوتر
- 🖥️ أي جهاز بمتصفح حديث

### تحسينات الجوال:
- ✅ أزرار كبيرة سهلة اللمس
- ✅ شاشة ملء الشاشة
- ✅ أداء سلس 60fps

---

## 🎨 التخصيص

### تغيير الألوان
```css
:root {
    --accent: #00ff88;        /* اللون الرئيسي */
    --bg: #0a0a0f;            /* خلفية داكنة */
    --gold: #ffd700;          /* اللون الذهبي */
    --danger: #ff4444;        /* اللون الأحمر */
}
```

### إضافة فرق جديدة
```javascript
const teams = [
    { flag: '🇳🇱', name: 'هولندا', color: '#FF6B00', difficulty: 1.2 },
    // أضف المزيد...
];
```

### تعديل صعوبة الحارس
```javascript
// في دالة shoot()
const keeperDive = (Math.random() - 0.5) * 100 * selectedTeam.difficulty;
// difficulty: 1.0 = سهل, 1.5 = صعب
```

---

## 📊 إحصائيات متوقعة

| المؤشر | القيمة |
|--------|--------|
| 🎮 مستخدمين يومياً | 1,000 - 10,000+ |
| 💰 إيرادات شهرياً | $500 - $5,000+ |
| ⏱️ وقت اللعب المتوسط | 3-5 دقائق |
| 🔄 معدل العودة | 65%+ |

---

## 🤝 المساهمة

نرحب بمساهماتكم! يمكنكم:

1. 🍴 Fork المشروع
2. 🌿 إنشاء فرع جديد: `git checkout -b feature/AmazingFeature`
3. 💾 Commit التغييرات: `git commit -m 'Add some AmazingFeature'`
4. 📤 Push للفرع: `git push origin feature/AmazingFeature`
5. 📋 فتح Pull Request

---

## 📜 الترخيص

هذا المشروع مرخص بموجب [MIT License](LICENSE) - مفتوح المصدر ومجاني للجميع.

```
Copyright (c) 2026 Penalty World Cup

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software...
```

---

## 🙏 شكر وتقدير

- 🎨 [Google Fonts](https://fonts.google.com) - خطوط Cairo و Orbitron
- ⚽ FIFA World Cup - الإلهام من كرة القدم العالمية
- 💻 مجتمع المصدر المفتوح

---

<div align="center">

**⭐ لا تنسَ إعطاء نجمة للمشروع إذا أعجبك!**

[🐛 الإبلاغ عن مشكلة](https://github.com/yourname/penalty-world-cup/issues) • [💡 اقتراح ميزة](https://github.com/yourname/penalty-world-cup/issues)

Made with ❤️ and ⚽

</div>
