<!-- ============================================
     🔥 Firebase Integration - Leaderboard
     ============================================ -->

<!-- 1. أضف هذا في <head> -->
<script type="module">
  // Import Firebase
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-app.js";
  import { getFirestore, collection, addDoc, query, orderBy, limit, getDocs, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-firestore.js";

  // إعدادات Firebase (استبدلها بإعداداتك)
  const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "your-project.firebaseapp.com",
    projectId: "your-project-id",
    storageBucket: "your-project.appspot.com",
    messagingSenderId: "123456789",
    appId: "1:123456789:web:abcdef123456"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app);

  // ==========================================
  // 🏆 Leaderboard Functions
  // ==========================================

  /**
   * حفظ النتيجة في التصنيف العالمي
   */
  window.saveScore = async function(playerName, team, goals, points) {
    try {
      await addDoc(collection(db, "leaderboard"), {
        playerName: playerName || "لاعب مجهول",
        team: team,
        goals: goals,
        points: points,
        timestamp: serverTimestamp()
      });
      console.log("Score saved!");
    } catch (e) {
      console.error("Error saving score: ", e);
    }
  };

  /**
   * جلب أفضل 10 نتائج
   */
  window.getLeaderboard = async function() {
    try {
      const q = query(
        collection(db, "leaderboard"),
        orderBy("points", "desc"),
        limit(10)
      );
      const querySnapshot = await getDocs(q);
      const leaderboard = [];
      querySnapshot.forEach((doc) => {
        leaderboard.push(doc.data());
      });
      return leaderboard;
    } catch (e) {
      console.error("Error getting leaderboard: ", e);
      return [];
    }
  };
</script>

<!-- ============================================
     🏆 إضافة زر التصنيف العالمي في HTML
     ============================================ -->

<!-- أضف هذا في شاشة النهاية -->
<div id="leaderboardSection" style="display:none; margin: 1rem 0; padding: 1rem; background: rgba(255,255,255,0.05); border-radius: 12px; width: 100%; max-width: 300px;">
    <h3 style="color: var(--gold); margin-bottom: 0.5rem;">🏆 التصنيف العالمي</h3>
    <div id="leaderboardList"></div>
    <input type="text" id="playerNameInput" placeholder="اسمك" style="margin-top: 0.5rem; padding: 0.5rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2); background: rgba(255,255,255,0.05); color: white; width: 100%; text-align: center;">
    <button onclick="submitScore()" style="margin-top: 0.5rem; padding: 0.5rem 1rem; background: var(--accent); color: var(--bg); border: none; border-radius: 8px; cursor: pointer; width: 100%;">📤 إرسال النتيجة</button>
</div>

<!-- ============================================
     🏆 دوال JavaScript للتصنيف
     ============================================ -->

<script>
/**
 * إظهار قسم التصنيف
 */
function showLeaderboard() {
    document.getElementById('leaderboardSection').style.display = 'block';
    loadLeaderboard();
}

/**
 * تحميل التصنيف العالمي
 */
async function loadLeaderboard() {
    const list = document.getElementById('leaderboardList');
    list.innerHTML = '<p style="color: var(--text-dim);">جاري التحميل...</p>';

    const scores = await getLeaderboard();

    if (scores.length === 0) {
        list.innerHTML = '<p style="color: var(--text-dim);">لا توجد نتائج بعد!</p>';
        return;
    }

    let html = '<table style="width: 100%; text-align: center; font-size: 0.85rem;">';
    html += '<tr style="color: var(--text-dim);"><th>#</th><th>اللاعب</th><th>الفريق</th><th>النقاط</th></tr>';

    scores.forEach((score, index) => {
        const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}`;
        html += `<tr style="border-bottom: 1px solid rgba(255,255,255,0.1);">
            <td style="padding: 0.3rem;">${medal}</td>
            <td style="padding: 0.3rem;">${score.playerName}</td>
            <td style="padding: 0.3rem;">${score.team}</td>
            <td style="padding: 0.3rem; color: var(--gold);">${score.points}</td>
        </tr>`;
    });

    html += '</table>';
    list.innerHTML = html;
}

/**
 * إرسال النتيجة
 */
async function submitScore() {
    const name = document.getElementById('playerNameInput').value;
    if (!name) {
        alert('❌ أدخل اسمك أولاً!');
        return;
    }

    await saveScore(name, selectedTeam ? selectedTeam.name : 'غير معروف', goals, points);
    alert('✅ تم إرسال النتيجة!');
    loadLeaderboard();
}
</script>

<!-- ============================================
     🔥 خطوات إعداد Firebase
     ============================================ -->

<!--
1. اذهب إلى https://console.firebase.google.com
2. أنشئ مشروع جديد
3. فعّل Firestore Database
4. اذهب إلى الإعدادات → تطبيق الويب
5. انسخ الإعدادات والصقها في firebaseConfig أعلاه
6. في قواعد Firestore، اضف:

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /leaderboard/{document} {
      allow read: if true;
      allow write: if request.resource.data.points is number 
                    && request.resource.data.points >= 0
                    && request.resource.data.points <= 10000;
    }
  }
}

7. احفظ القواعد
-->
